<?php
$mail->Subject = 'Resetting your Password';
$mail->addEmbeddedImage('images/GamePointLogo.png', 'logoIMG');
?>