<?php
$mail->Subject = 'We have recieved your return request';
$mail->addEmbeddedImage('images/GamePointLogo.png', 'logoIMG');
?>