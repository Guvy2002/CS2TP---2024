<?php
$mail->Subject = 'Thank you for Contacting';
$mail->addEmbeddedImage('images/GamePointLogo.png', 'logoIMG');
?>