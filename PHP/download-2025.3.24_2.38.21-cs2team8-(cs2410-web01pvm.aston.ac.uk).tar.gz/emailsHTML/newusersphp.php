<?php
$mail->Subject = 'Welcome to GamePoint';
$mail->addEmbeddedImage('images/GamePointLogo.png', 'logoIMG');
?>