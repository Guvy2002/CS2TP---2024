<?php
$mail->Subject = 'GamePoint Newsletter';
$mail->addEmbeddedImage('images/GamePointLogo.png', 'logoIMG');
$mail->addEmbeddedImage('images/81PLIy9MmSL._AC_UF1000,1000_QL80_.jpg', 'upcomingIMG');
$mail->addEmbeddedImage('images/70900269_l.avif', 'upcomingIMG2');
?>